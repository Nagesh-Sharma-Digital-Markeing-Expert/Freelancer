$(document).ready(function() {

	/*============================================
	Flexslider
	==============================================*/
	$('.testimonials-slider').flexslider({
		animation: "fade",
		controlsContainer: $(".custom-controls-container"),
		customDirectionNav: $(".custom-navigation a")
	});
		
		

});

